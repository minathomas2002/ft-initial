export const environment = {
  production: false,
  baseUrl: 'https://rmt-itweb-shr01/bena/api',
  apiVersion: 'v1',
  appName: 'BENA - STAGING',
  enableDebug: true,
  secDomain: 'http://localhost:4200'//should be updated with sec internal domain
};

