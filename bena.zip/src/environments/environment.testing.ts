export const environment = {
  production: false,
  baseUrl: 'http://10.15.1.68/api',
  apiVersion: 'v1',
  appName: 'Benaa',
  enableDebug: true,
  secDomain: 'http://localhost:4200'//should be updated with sec internal domain
};

