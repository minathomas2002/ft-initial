export * from './translate.pipe';

