export interface IFilterAdapter<T> {
	adaptFilter(): T;
}
