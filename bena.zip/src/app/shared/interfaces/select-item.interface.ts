export interface ISelectItem {
	id: string;
	name: string;
	icon?: string;
}