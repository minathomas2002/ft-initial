export enum ERoles {
    ADMIN = 1,
    INVESTOR = 2,
    EMPLOYEE = 3,
    MANAGER = 4,
    DEPARTMENT_MANAGER = 5
}

export enum ERoleNames {
    Admin = "Admin",
    Investor = "Investor",
    Employee = "Employee",
    Manager = "Manager",
    DepartmentManager = "DepartmentManager"
}