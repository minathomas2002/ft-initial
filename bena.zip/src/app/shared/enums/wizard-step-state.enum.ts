export enum EWizardStepState {
  Active = 'active',
  Incomplete = 'incomplete',
  Completed = 'complete',
  Error = 'error',
}