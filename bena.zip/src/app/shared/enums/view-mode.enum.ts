export enum EViewMode {
  Create = 'create',
  Edit = 'edit',
}