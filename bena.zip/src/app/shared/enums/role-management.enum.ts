export enum ERoleManagementActions {
  TRANSFER = 'transfer',
}